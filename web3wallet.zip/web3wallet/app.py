from flask import Flask, request, jsonify
from flask_cors import CORS
from web3 import Web3
from eth_account.messages import encode_defunct

app = Flask(__name__)
CORS(app)

@app.route('/verify_signature', methods=['POST'])
def verify_signature():
    data = request.json
    signature = data.get('signature')
    userAddress = data.get('userAddress')
    originalMessage = "Please sign this message to verify your identity."

    if not signature or not userAddress:
        return jsonify({"error": "Signature and user address are required"}), 400

    if verify_user_signature(userAddress, signature, originalMessage):
        return jsonify({"status": "Verified"})
    else:
        return jsonify({"status": "Verification failed"}), 401

def verify_user_signature(userAddress, signature, originalMessage):
    w3 = Web3()
    message_hash = encode_defunct(text=originalMessage)
    recovered_address = w3.eth.account.recover_message(message_hash, signature=signature)
    return recovered_address.lower() == userAddress.lower()

if __name__ == '__main__':
    app.run(debug=True)
