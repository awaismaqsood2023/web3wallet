import React, { useState, useEffect } from "react";
import { ethers } from "ethers";
import "./App.css";
import { Button, Card } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  const [data, setData] = useState({
    address: "",
    balance: null,
    isConnected: false,
    isSigned: false,
  });

  // Function to handle account change
  const accountChangeHandler = (account) => {
    setData({
      address: account,
      balance: null, // Reset balance to null until fetched
      isConnected: true,
    });
    getBalance(account);
  };

  const signMessage = async () => {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const message = "Please sign this message to verify your identity.";
      const signature = await signer.signMessage(message);
      const userAddress = await signer.getAddress();

      console.log("Signature:", signature);
      console.log("User Address:", userAddress);

      fetch("http://localhost:5000/verify_signature", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          signature: signature,
          userAddress: userAddress,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log("Verification Status:", data);
          // Update the state based on the verification status
          if (data.status === "Verified") {
            alert("Signature verified successfully!");
            setData((prevState) => ({
              ...prevState,
              isSigned: true,
            }));
          } else {
            alert("Signature verification failed.");
          }
        })
        .catch((error) => {
          console.error("Error:", error);
          alert("Error sending signature for verification");
        });
    } catch (err) {
      console.error("Error signing message:", err);
      alert("Error signing message");
    }
  };


  // Function to get balance
  const getBalance = (address) => {
    window.ethereum
      .request({
        method: "eth_getBalance",
        params: [address, "latest"],
      })
      .then((balance) => {
        setData((prevState) => ({
          ...prevState,
          balance: ethers.utils.formatEther(balance),
        }));
      });
  };

  // Function to handle metamask connection
  const btnHandler = () => {
    if (window.ethereum) {
      window.ethereum
        .request({ method: "eth_requestAccounts" })
        .then((res) => accountChangeHandler(res[0]));
    } else {
      alert("Please install the MetaMask extension!");
    }
  };

  // to check for previously granted permissions
  useEffect(() => {
    if (window.ethereum) {
      window.ethereum.request({ method: "eth_accounts" }).then((accounts) => {
        if (accounts.length > 0) {
          // Account is already connected
          accountChangeHandler(accounts[0]);
        }
      });
    }
  }, []);

  return (
    <div className="App">
      <Card className="text-center">
        <Card.Header>
          <strong>Address: </strong>
          {data.address || "Not connected"}
        </Card.Header>
        <Card.Body>
          <Card.Text>
            <strong>Balance: </strong>
            {data.balance || "N/A"}
          </Card.Text>
          <Button
            onClick={btnHandler}
            variant="primary"
            disabled={data.isConnected}
          >
            {data.isConnected ? "Wallet Connected" : "Connect to Wallet"}
          </Button>
          <Button
            onClick={signMessage}
            variant="secondary"
            disabled={!data.isConnected || data.isSigned}
          >
            {data.isSigned ? "Message Signed" : "Sign Message"}
          </Button>
        </Card.Body>
      </Card>
    </div>
  );
}

export default App;
